// custom SAPI TTS adapter for motion-showreel's narration.mjs
// Exports synthesize({text, outFile}) — required by narration-providers.mjs.
// Fully offline: Windows SAPI via local Python, no credentials, no network.
//
// Why the extra ffmpeg step: SAPI Huihui emits speech at about -24 LUFS with a
// -3.6 dBFS peak. Mixed against a -14 LUFS score, the film's loudnorm cannot
// reach -14 LUFS without clipping, so the whole film lands at -15.9 LUFS and
// fails the technical loudness check. Compressing + normalising each spoken
// segment at the TTS exit gives the mix enough headroom. Text and timing are
// untouched — this is audio-domain processing only.
//
// NOTE: uses ASYNC spawn (not spawnSync). Some sandboxed Windows environments
// reject synchronous child processes with EBUSY while async spawn works fine.
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PY = process.env.SAPI_PYTHON
  || 'C:/Users/Amber/.workbuddy/binaries/python/versions/3.13.12/python.exe';
const FFMPEG = process.env.SAPI_FFMPEG || 'ffmpeg';
const SPEAK = path.join(HERE, 'sapi_speak.py');
const VOICE_CHAIN = 'acompressor=threshold=0.05:ratio=4:attack=5:release=60,loudnorm=I=-14:TP=-1.5:LRA=7';

function run(bin, args, text) {
  return new Promise((resolve, reject) => {
    const child = spawn(bin, args, { windowsHide: true, stdio: ['pipe', 'ignore', 'pipe'] });
    let err = '';
    child.stderr.on('data', d => { err += d.toString('utf8'); });
    child.on('error', e => reject(new Error(`${path.basename(bin)} spawn failed: ${e.message}`)));
    child.on('close', code => {
      if (code !== 0) reject(new Error(`${path.basename(bin)} failed (exit ${code}): ${err.slice(0, 400)}`));
      else resolve();
    });
    if (text === undefined) child.stdin.end();
    else child.stdin.end(Buffer.from(text, 'utf8'));
  });
}

export async function synthesize({ text, outFile }) {
  fs.mkdirSync(path.dirname(path.resolve(outFile)), { recursive: true });
  const raw = `${outFile}.raw.wav`;
  try {
    await run(PY, [SPEAK, raw], text);
    if (!fs.existsSync(raw) || fs.statSync(raw).size < 1000) throw new Error('SAPI produced no usable WAV');
    // The Skill hands the adapter a temp file ending in `.bin`, so ffmpeg
    // cannot infer a container from the name: force WAV explicitly.
    await run(FFMPEG, [
      '-hide_banner', '-loglevel', 'error', '-y', '-i', raw,
      '-af', VOICE_CHAIN, '-ar', '48000', '-ac', '2', '-c:a', 'pcm_s16le',
      '-f', 'wav', outFile,
    ]);
  } finally {
    fs.rmSync(raw, { force: true });
  }
  if (!fs.existsSync(outFile) || fs.statSync(outFile).size < 1000) {
    throw new Error('Voice normalisation produced no usable WAV');
  }
}
