#!/bin/sh
# 一键重建科普教学片（含本机环境准备）。
# 用法： sh tools/rebuild.sh
# 前置：motion-showreel 已装在 ~/.workbuddy/skills/motion-showreel
set -e
P=$(cd "$(dirname "$0")/.." && pwd)
SKILL="${SKILL:-C:/Users/Amber/.workbuddy/skills/motion-showreel}"
NODE_DIR="/c/Users/Amber/.workbuddy/binaries/node/versions/22.22.2-6"
BIN="/d/03-Codes/2026-09-20-01-46-40/.workbuddy/tmp-skill-audit/bin"

# ffmpeg 6.1.1 + ffprobe 4.0.2（本机 Tecplot 自带的 4.3.1 缺 amix normalize / alimiter latency）
# 若 bin 目录不存在，可用 imageio-ffmpeg 提供的 ffmpeg 9.0.2 与 ffprobe-static 重建。
export PATH="$BIN:$NODE_DIR:$PATH"
# 兼容层：本机沙箱会拒绝未显式声明 stdio 的同步子进程（EBUSY）。
# NODE_OPTIONS 由 node 自己解析，不经过 MSYS 转换，必须用 Windows 路径。
WB_SHIM="$P/tools/sync-shim.cjs"
if command -v cygpath >/dev/null 2>&1; then WB_SHIM=$(cygpath -w "$WB_SHIM"); fi
export NODE_OPTIONS="--require $WB_SHIM"
export CHROME_PATH="${CHROME_PATH:-C:/Program Files/Google/Chrome/Application/chrome.exe}"
export SKILL
export SAPI_RATE=1

cd "$P"

echo "[1/5] 从真实音频重建时间轴与字幕"
"C:/Users/Amber/.workbuddy/binaries/python/versions/3.13.12/python.exe" tools/gen_timeline.py

echo "[2/5] 离线中文口播（逐字稿件 + Windows SAPI）"
# Skill 的段缓存 key 只含文本与 provider 名；改了 adapter 里的响度链不会自动失效，
# 因此每次重建显式清缓存，保证口播与 mix.json / narration.json 的哈希链一致。
rm -rf "$P/audio/narration-cache"
node "$SKILL/scripts/narration.mjs" tts "$P" \
  --script "$P/tools/script.json" --source user \
  --provider "$P/tools/sapi-tts.mjs" --duration 90

echo "[3/5] 轻 pad 配乐"
node "$SKILL/scripts/audio.mjs" build "$P/score.mjs" --out "$P/audio/music.wav"

echo "[4/5] 混音（人声优先，duck -16dB）"
node "$SKILL/scripts/narration.mjs" mix "$P" \
  --bgm audio/music.wav --bgm-source ai \
  --sfx none --sfx-source none \
  --duration 90 --bgm-gain 0.24 --duck-db -16 \
  --out audio/final.wav

echo "[5/5] 渲染 + 确定性检查 + 技术验收"
sh build.sh

echo "✓ 成片： $P/out/final.mp4"
