#!/usr/bin/env python3
"""本机离线中文语音合成：Windows SAPI (Microsoft Huihui)。

零联网、零凭据。通过 stdin 读 UTF-8 文本，把 WAV 写到 argv[1]。
供 custom SAPI TTS adapter (sapi-tts.mjs) 调用。
"""
import os
import sys

import win32com.client


def main() -> None:
    out = sys.argv[1]
    text = sys.stdin.buffer.read().decode("utf-8").strip()
    rate = int(os.environ.get("SAPI_RATE", "1"))  # -10..10，1 略快于默认，适合教学片

    voice = win32com.client.Dispatch("SAPI.SpVoice")
    for candidate in voice.GetVoices():
        if "Huihui" in candidate.GetDescription():
            voice.Voice = candidate
            break
    voice.Rate = max(-10, min(10, rate))

    stream = win32com.client.Dispatch("SAPI.SpFileStream")
    # SSFMCreateForWrite = 3；SAPI 默认写出 22.05kHz 16bit PCM WAV，
    # Skill 随后会统一归一化到 48kHz 双声道。
    stream.Open(out, 3)
    voice.AudioOutputStream = stream
    try:
        voice.Speak(text)
    finally:
        stream.Close()


if __name__ == "__main__":
    main()
