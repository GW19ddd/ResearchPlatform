// 抓若干时间点的确定性画面，供人工复核构图（不属于成片产物）
import { pathToFileURL } from 'node:url';
import { writeFileSync } from 'node:fs';

const SKILL = 'C:/Users/Amber/.workbuddy/skills/motion-showreel/scripts/lib/browser.mjs';
const { serve, loadChromium, launch, openPage } = await import(pathToFileURL(SKILL).href);

const times = [1.2, 6.0, 18.0, 33.0, 48.0, 59.0, 70.0, 84.0];
const { server, port } = await serve(process.cwd());
let browser;
try {
  const chromium = await loadChromium();
  browser = await launch(chromium);
  const page = await openPage(browser, {
    port, rel: 'index.html', w: 1920, h: 1080, dpr: 1,
    query: 'render=1',
  });
  for (const t of times) {
    await page.evaluate(tt => window.render(tt), t);
    const name = `qa/v3-t${String(t).replace('.', '_')}.png`;
    await page.screenshot({ path: name });
    console.log('FRAME', t, name);
  }
} finally {
  if (browser) await browser.close().catch(() => {});
  server.close();
}
writeFileSync('qa/v3-frames.json', JSON.stringify({ times }, null, 2));
console.log('FRAMES_DONE', times.length);
