"""Package the popular-science film and its editable source into the site assets.

Run from anywhere:  python tutorial/popular-science/tools/pack_delivery.py
Only copies files — never rewrites the film or the tutorial sources.
"""
from __future__ import annotations

import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]          # tutorial/popular-science
WEB = ROOT.parents[1] / "web"                      # growth-workbench/web
PUBLIC = WEB / "public" / "tutorial"
DIST = WEB / "dist" / "tutorial"

FILM = ROOT / "out" / "final.mp4"
FILM_NAME = "workbench-tutorial-popular.mp4"
ZIP_NAME = "workbench-tutorial-popular-source.zip"

# 画面用到的真实界面截图（v3 起）：源码包必须带上它们才能原样重渲染。
# 由 tutorial/build/build_ui_assets.py 从运行中的工作台统一生成，路径与 index.html 的 ./assets/ui/ 对应。
SHOT_FILES = [
    "assets/ui/ui-workbench.png",
    "assets/ui/ui-literature.png",
    "assets/ui/ui-ideas.png",
    "assets/ui/ui-canvas.png",
    "assets/ui/ui-research.png",
    "assets/ui/ui-experiments.png",
    "assets/ui/ui-studio-paper.png",
    "assets/ui/ui-paper-doc.png",
    "assets/ui/manifest.json",
]

# Editable source only. No rendered film or cache files.
SOURCE_FILES = [
    "brief.md",
    "index.html",
    "timeline.js",
    "subtitles.js",
    "score.mjs",
    "motion.js",
    "narration.js",
    "preview.js",
    "package.json",
    "build.sh",
    "audio/narration.json",
    "audio/mix.json",
    "tools/rebuild.sh",
    "tools/gen_timeline.py",
    "tools/sapi_speak.py",
    "tools/sapi-tts.mjs",
    "tools/script.json",
    "tools/sync-shim.cjs",
    "tools/preview_frames.mjs",
    "tools/pack_delivery.py",
    *SHOT_FILES,
]


def main() -> None:
    if not FILM.is_file() or FILM.stat().st_size < 1_000_000:
        raise SystemExit(f"film missing or too small: {FILM}")
    PUBLIC.mkdir(parents=True, exist_ok=True)
    DIST.mkdir(parents=True, exist_ok=True)

    for dest_dir in (PUBLIC, DIST):
        shutil.copy2(FILM, dest_dir / FILM_NAME)

    zip_path = PUBLIC / ZIP_NAME
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel in SOURCE_FILES:
            src = ROOT / rel
            if not src.is_file():
                raise SystemExit(f"source file missing: {src}")
            z.write(src, f"workbench-tutorial-popular/{rel}")
    shutil.copy2(zip_path, DIST / ZIP_NAME)

    print(f"film  : {FILM.stat().st_size / 1e6:.2f} MB -> {FILM_NAME} (public + dist)")
    print(f"source: {len(SOURCE_FILES)} files -> {ZIP_NAME} ({zip_path.stat().st_size / 1e3:.0f} KB)")
    for rel in SOURCE_FILES:
        print(f"  + {rel}")


if __name__ == "__main__":
    main()
