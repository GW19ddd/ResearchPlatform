// Windows sandbox compatibility preload for motion-showreel.
//
// Two facts about this machine, both verified by direct probes:
//   1. Any synchronous child process WITHOUT an explicit `stdio` option is
//      rejected by the sandbox with `EBUSY spawnSync <cmd> EBUSY`. This is true
//      whether or not `encoding` is set. Supplying stdio (array or 'inherit')
//      makes the exact same call succeed.
//   2. When `encoding: 'utf8'` is present, stripping it and decoding the Buffer
//      ourselves is behaviourally identical and avoids other sandbox quirks.
//
// So: always inject an explicit stdio when the caller did not provide one, and
// keep the caller's stdio untouched when it did. Loaded via
//   NODE_OPTIONS="--require <project>/tools/sync-shim.cjs"
const cp = require('node:child_process');

const DEFAULT_STDIO = ['ignore', 'pipe', 'pipe'];
const origSpawnSync = cp.spawnSync;
const origExecFileSync = cp.execFileSync;
const origExecSync = cp.execSync;

// Normalize the argument list of spawnSync / execFileSync / execSync:
// return a copy with an options object that has stdio, plus the encoding we
// stripped (if any) so the result can be decoded back to the original shape.
function normalize(args) {
  const call = [...args];
  let i = call.findIndex(a => a && typeof a === 'object' && !Array.isArray(a) && !Buffer.isBuffer(a));
  let opts;
  if (i < 0) {
    opts = {};
    call.push(opts);
  } else {
    opts = { ...call[i] };
    call[i] = opts;
  }
  if (opts.stdio === undefined) opts.stdio = DEFAULT_STDIO;
  let enc = null;
  if (typeof opts.encoding === 'string' && opts.encoding !== 'buffer') {
    enc = opts.encoding;
    delete opts.encoding;
  }
  return { call, enc, i };
}

const decode = (v, enc) => enc && Buffer.isBuffer(v) ? v.toString(enc) : v;

function patch(fn, isSpawn) {
  if (!fn) return fn;
  return function (...args) {
    const { call, enc } = normalize(args);
    const r = fn.apply(this, call);
    if (!enc) return r;
    if (isSpawn) {
      if (r && typeof r === 'object') {
        if (Buffer.isBuffer(r.stdout)) r.stdout = decode(r.stdout, enc);
        if (Buffer.isBuffer(r.stderr)) r.stderr = decode(r.stderr, enc);
        if (Array.isArray(r.output)) r.output = r.output.map(x => decode(x, enc));
      }
      return r;
    }
    return decode(r, enc);
  };
}

cp.spawnSync = patch(origSpawnSync, true);
cp.execFileSync = patch(origExecFileSync, false);
cp.execSync = patch(origExecSync, false);
