#!/usr/bin/env python3
"""从 audio/narration.json 生成 timeline.js 与 subtitles.js。

时间轴与字幕都来自真实合成音频，杜绝手抄导致的漂移。
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
NARR = json.loads((ROOT / "audio/narration.json").read_text(encoding="utf-8"))
SCRIPT = json.loads((ROOT / "tools/script.json").read_text(encoding="utf-8"))
FROM = {s["id"]: s["from"] for s in SCRIPT["segments"]}

TITLES = {
    "s1": "每个功能点，都配一条示例",
    "s2": "六章，一张全局地图",
    "s3": "上一站的产出，是下一站的输入",
    "s4": "引用可以点开核对",
    "s5": "只给口径，不给数值",
    "s6": "演示占位，不是实测",
}
DUR = 90.0

segs = []
for s in NARR["segments"]:
    segs.append({
        "id": s["id"],
        "t0": round(s["start"], 3),
        "t1": round(s["end"], 3),
        "title": TITLES[s["id"]],
        "text": s["text"],
        "from": FROM[s["id"]],
    })
tail = round(NARR["duration"], 3)

lines = [
    "// 自动生成，请勿手改。源：audio/narration.json（真实语音时间轴）",
    "// 重新生成：python tools/gen_timeline.py",
    "export const DUR = 90;",
    "export const FPS = 30;",
    "export const BPM = 76;",
    "export const BEAT = 60 / BPM;",
    "export const BAR = BEAT * 4;",
    "export const b = n => n * BEAT;",
    f"export const TAIL = {tail};",
    "export const SEGS = " + json.dumps(
        [{k: v for k, v in s.items() if k != "text"} for s in segs],
        ensure_ascii=False, indent=2) + ";",
    "export const SHOTS = [",
    "  { id: 'intro', t0: 0, t1: 3 },",
    *[f"  {{ id: '{s['id']}', t0: {s['t0']}, t1: {s['t1']} }}," for s in segs],
    f"  {{ id: 'tail', t0: {tail}, t1: 90 }},",
    "];",
    "export const CUES = SEGS.slice(1).map(s => ({ t: s.t0, sfx: 'tick' }));",
    "export const HOLDS = [[84, 90]];",
    "export const DROPS = [];",
    "",
]
(ROOT / "timeline.js").write_text("\n".join(lines), encoding="utf-8")

subs = [
    "// 自动生成，请勿手改。源：tools/script.json（逐字摘录自 tourContent.json）",
    "export const SUBTITLES = " + json.dumps(
        [{"id": s["id"], "t0": s["t0"], "t1": s["t1"], "text": s["text"], "from": s["from"]} for s in segs],
        ensure_ascii=False, indent=2) + ";",
    "",
]
(ROOT / "subtitles.js").write_text("\n".join(subs), encoding="utf-8")

print(f"生成 timeline.js / subtitles.js：{len(segs)} 段，口播 {tail}s，片长 {DUR}s")
for s in segs:
    print(f"  {s['id']} {s['t0']:7.3f} → {s['t1']:7.3f}  {len(s['text'])}字  {s['from']}")
