// score.mjs — 科普教学片配乐。极轻，无鼓点，人声优先。
// 只有缓慢的和弦 pad 与段切换处的轻 tick；不做 kick/clap/riser/impact。
import { DUR, BPM, CUES } from './timeline.js';
export { DUR };

export default function score(S) {
  S.tempo(BPM);
  const pad = S.bus('pad', { gain: 0.22, reverb: 0.42, duck: 0.55, highpass: 120 });
  const air = S.bus('air', { gain: 0.10, reverb: 0.5, duck: 0.6 });
  const sfx = S.bus('sfx', { gain: 0.10, reverb: 0.2 });

  // 两个和弦缓慢交替，不制造戏剧弧线
  const prog = [['A2', 'min7'], ['F2', 'maj7']];
  const bars = Math.round(DUR / S.bar(1));
  for (let bar = 0; bar < bars; bar++) {
    const [root, quality] = prog[bar % prog.length];
    const t = S.bar(bar);
    pad.add(S.pad(S.chord(S.midi(root) + 12, quality), S.bar(1) * 1.08,
      { cutoff: 1100, attack: 1.1, release: 1.6, voices: 4, wobble: 0.08 }), t);
    // 每两小节一个很轻的高音点缀
    if (bar % 2 === 0) air.add(S.bell(S.midi('E5'), 2.4, { decay: 2.0 }), t + S.beat(2));
  }

  // 段切换仅一个轻 tick，与 timeline 的 CUES 共用同一批秒数
  for (const c of CUES) if (c.sfx === 'tick') sfx.add(S.tick({ tone: 0.7 }), c.t, { gain: 0.28 });
}
