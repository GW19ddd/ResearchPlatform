// 自动生成，请勿手改。源：audio/narration.json（真实语音时间轴）
// 重新生成：python tools/gen_timeline.py
export const DUR = 90;
export const FPS = 30;
export const BPM = 76;
export const BEAT = 60 / BPM;
export const BAR = BEAT * 4;
export const b = n => n * BEAT;
export const TAIL = 77.886;
export const SEGS = [
  {
    "id": "s1",
    "t0": 0,
    "t1": 13.111,
    "title": "每个功能点，都配一条示例",
    "from": "slide 01 (cover)"
  },
  {
    "id": "s2",
    "t0": 13.111,
    "t1": 27.472,
    "title": "六章，一张全局地图",
    "from": "slide 02 (map)"
  },
  {
    "id": "s3",
    "t0": 27.472,
    "t1": 43.322,
    "title": "上一站的产出，是下一站的输入",
    "from": "slide 13 (flow)"
  },
  {
    "id": "s4",
    "t0": 43.322,
    "t1": 55.615,
    "title": "引用可以点开核对",
    "from": "slide 04 (chapter)"
  },
  {
    "id": "s5",
    "t0": 55.615,
    "t1": 63.749,
    "title": "只给口径，不给数值",
    "from": "slide 08 (chapter)"
  },
  {
    "id": "s6",
    "t0": 63.749,
    "t1": 77.886,
    "title": "演示占位，不是实测",
    "from": "slide 14 (end)"
  }
];
export const SHOTS = [
  { id: 'intro', t0: 0, t1: 3 },
  { id: 's1', t0: 0, t1: 13.111 },
  { id: 's2', t0: 13.111, t1: 27.472 },
  { id: 's3', t0: 27.472, t1: 43.322 },
  { id: 's4', t0: 43.322, t1: 55.615 },
  { id: 's5', t0: 55.615, t1: 63.749 },
  { id: 's6', t0: 63.749, t1: 77.886 },
  { id: 'tail', t0: 77.886, t1: 90 },
];
export const CUES = SEGS.slice(1).map(s => ({ t: s.t0, sfx: 'tick' }));
export const HOLDS = [[84, 90]];
export const DROPS = [];
